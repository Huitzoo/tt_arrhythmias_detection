# Codigo de TT 

-- python 3.6.5 <br/>
-- Versión de Django 2.1.5 <br/>

-- Tensor flow:<br/>
-- pip3 install tensorflow <br/>

-- Django <br/>
-- pip3 install Django==2.1.5

-- Django rest framework <br/>
-- pip3 install djangorestframework
-- pip3 install markdown
-- pip3 install django-filter
